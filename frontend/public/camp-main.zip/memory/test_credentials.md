# test_credentials.md

## Admin Account
- Email: admin@camp.com
- Password: admin123
- Role: admin

## System Info
- Backend URL: https://aid-family-manager.preview.emergentagent.com
- Frontend URL: https://aid-family-manager.preview.emergentagent.com
- Firebase DB: https://camp-50ca4-default-rtdb.firebaseio.com
