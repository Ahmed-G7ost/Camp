# PRD.md - مخيم العائدين
**نظام إدارة وتوزيع المساعدات**

---

## المشكلة الأصلية
إصلاح مشاكل البناء لـ Vercel، وإضافة ميزات جديدة:
1. إضافة أفراد العائلة يدوياً
2. إضافة زر حذف الكل في جميع القوائم مع ConfirmDialog احترافي
3. نوافذ منبثقة احترافية بتأثيرات Glassmorphism
4. فصل تسجيل العائلة الأساسية عن تسجيل الأفراد المفصّل
5. إصلاح استيراد Excel مع fuzzy matching للأسماء العربية
6. تكامل Firebase Authentication

---

## البنية التقنية
- **Frontend**: React 19 + Tailwind CSS + craco + React Query + Sonner
- **Backend**: FastAPI (Python) + Firebase Realtime Database
- **Auth**: Firebase Authentication (client) + JWT tokens (server) + bcrypt
- **Design**: Glassmorphism UI + RTL Arabic + Cairo/Tajawal fonts
- **Deployment**: Vercel (frontend) + separate hosting (backend)

---

## ما تم تنفيذه

### الجلسة الأولى (Iteration 1-2)
- **حذف صفحة أفراد العائلة المكررة** من القائمة
- **DELETE /families/all** - حذف جميع العائلات + زر "حذف الكل"
- **إصلاح Excel import** - إزالة Content-Type اليدوي من FormData
- **ConfirmDialog احترافي** يستبدل window.confirm مع Glassmorphism

### الجلسة الثانية (Iteration 3) - فبراير 2026
- **إصلاح IndividualMembers.jsx** - إصلاح خطأ `calcAge` بدون declaration + JSX مكرر
- **تفعيل Firebase Auth** - تحديث API key حقيقي في `.env`
- **عداد الأفراد** في نموذج إضافة الأفراد المفصّل (يستثني رب الأسرة والزوجة)
- **Fuzzy Matching** لاستيراد Excel (نسبة مطابقة 0.60 مع تطبيع أسماء عربية)
- **DELETE /aid-records/all** + زر حذف الكل في صفحة المساعدات

### إصلاحات Vercel
- نقل `@emergentbase/visual-edits` من devDependencies إلى optionalDependencies
- إنشاء `frontend/vercel.json` مع rewrites للـ SPA routing
- إنشاء root `vercel.json` للـ monorepo setup

### ميزات مكتملة
1. **تسجيل الدخول** - Firebase Auth مع fallback لـ classic JWT
2. **صفحة العائلات** - CRUD كامل + استيراد/تصدير Excel
3. **صفحة أفراد مفصّل** - ربط بعائلات + عداد ذكي (يستثني رب/زوجة)
4. **سجلات المساعدات** - عرض + استيراد + تصدير + حذف الكل
5. **الإعدادات** - إدارة المستخدمين + حقول العائلة + أنواع المساعدات

---

## المستخدمون والصلاحيات
- **Admin**: admin@camp.com / admin123 - يصل لجميع الصفحات
- **Staff**: صلاحية محدودة (لا يصل للإعدادات وأنواع المساعدات)

---

## Firebase Configuration
- **Project**: camp-50ca4
- **Auth Domain**: camp-50ca4.firebaseapp.com
- **Database URL**: https://camp-50ca4-default-rtdb.firebaseio.com
- **Admin Email في Firebase Auth**: يحتاج إضافة يدوية في Firebase Console

---

## Backlog / Tasks

### P0 (حرجة)
- لا توجد مشاكل حرجة

### P1 (مهمة)
- [ ] إضافة admin@camp.com في Firebase Auth Console لتفعيل Firebase Auth الكامل
- [ ] إضافة pagination للجداول الكبيرة (319+ عائلة)
- [ ] تصدير أفراد العائلة إلى Excel

### P2 (مستقبلية)
- [ ] إشعارات وتنبيهات
- [ ] تقارير متقدمة
- [ ] استيراد أفراد العائلة من Excel
- [ ] نظام بحث متقدم مع فلاتر
- [ ] نسخة احتياطية تلقائية للبيانات
